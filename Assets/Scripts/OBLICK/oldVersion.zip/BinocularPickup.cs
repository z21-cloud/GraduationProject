using UnityEngine;

public class BinocularPickup : MonoBehaviour
{
    public SimpleScanner scanner;
    public PlayerInventory inventory;

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            inventory.PickUpBinocular(scanner);
            Debug.Log("Бинокль подобран!");
            Destroy(gameObject);
        }
    }
}
